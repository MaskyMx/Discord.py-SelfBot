import colorama 
from colorama import Fore, Style, init
import discord, random, aiohttp, asyncio
from discord.ext import commands
from discord.ext.commands import *
from colorama import Fore as C
from colorama import Style as S
import random
import time 

#####Please read HOWTOUSE.txt for information on this bot. Please be aware, I am not responsible for your actions and how you use this bot. This is for educational purposes only blah blah blah. #####


#In order for the bot to work correctly, you need to have your Discord account token. Your token is supposed to be a confidential piece of information that should not be shared with anybody, it is basically a one way ticket into your account lmao so don't be a moron and share it.#

####IF YOU HAVE ABSOLUTELY NO CLUE HOW TO GET YOUR DISCORD TOKEN, WATCH HERE https://www.youtube.com/results?search_query=how+to+find+your+discord+token
####

stream_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ" 
## ^^THIS IS SPECIFICALLY FOR THE STREAMING STATUS, YOU CAN CHANGE THIS TO WHATEVER YOU LIKE##
prefix = ">>"
### You can change the prefix to your liking, this is just the default ##
bot = commands.Bot(command_prefix=prefix, self_bot=True)


print(Fore.BLUE + """  

███╗░░░███╗░█████╗░░██████╗██╗░░██╗██╗░░░██╗██╗░██████╗
████╗░████║██╔══██╗██╔════╝██║░██╔╝╚██╗░██╔╝╚█║██╔════╝
██╔████╔██║███████║╚█████╗░█████═╝░░╚████╔╝░░╚╝╚█████╗░
██║╚██╔╝██║██╔══██║░╚═══██╗██╔═██╗░░░╚██╔╝░░░░░░╚═══██╗
██║░╚═╝░██║██║░░██║██████╔╝██║░╚██╗░░░██║░░░░░░██████╔╝
╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝░░░╚═╝░░░░░░╚═════╝░


░██████╗███████╗██╗░░░░░███████╗██████╗░░█████╗░████████╗
██╔════╝██╔════╝██║░░░░░██╔════╝██╔══██╗██╔══██╗╚══██╔══╝
╚█████╗░█████╗░░██║░░░░░█████╗░░██████╦╝██║░░██║░░░██║░░░
░╚═══██╗██╔══╝░░██║░░░░░██╔══╝░░██╔══██╗██║░░██║░░░██║░░░
██████╔╝███████╗███████╗██║░░░░░██████╦╝╚█████╔╝░░░██║░░░
╚═════╝░╚══════╝╚══════╝╚═╝░░░░░╚═════╝░░╚════╝░░░░╚═╝░░░

""")


print(Fore.RED + Style.BRIGHT + 'Creator: ཊ☬ཏ MΛƧKY ཊ☬ཏ#0666')
print(Fore.RED + Style.BRIGHT + 'Creator ID (in case tag does not work):  733917864725184614')

print(Fore.BLUE + Style.BRIGHT + 'Dont Skid It')

@bot.event
async def on_connect():
 print(f"""
 {Fore.WHITE}
 {Style.DIM}
 Logged in as: {bot.user.name} #{bot.user.discriminator} 
 """)


bot.remove_command("help")


@bot.command()
async def masky(ctx):
          channel = ctx.message.channel
          messages = await channel.history(limit=None).flatten()
          for message in messages:
            if message.author == bot.user:
              await message.delete()


@bot.command()
async def nick(ctx, rename_to):
        await ctx.message.delete()
        for user in list(ctx.guild.members):
            try:
                await user.edit(nick=rename_to)
                print (f"{user.name} has been renamed to {rename_to} in {ctx.guild.name}")
            except:
                print (f"{user.name} has NOT been renamed to {rename_to} in {ctx.guild.name}")
        print ("Nickname has Changed")


@bot.command()
async def serverinfo(ctx):
  guild = ctx.message.guild
  roles = [role for role in guild.roles]
  channels = [channel for channel in guild.channels]
  categories = [category for category in guild.categories]
  embed = discord.Embed(colour=0Xff0000, timestamp=ctx.message.created_at)
  embed.set_author(name=f"{guild.name}")
  embed.add_field(name=f"**Member Count:**", value=f"{guild.member_count}", inline=False)
  embed.add_field(name=f"**Role Count:**", value=f"{len(roles)}", inline=False)
  embed.add_field(name=f"**Channel Count:**", value=f"{len(channels)}", inline=False)
  embed.add_field(name=f"**Category Count:**", value=f"{len(categories)}", inline=False)
  embed.add_field(name=f"**Owner:**", value=f"{guild.owner}", inline=False)
  embed.set_thumbnail(url=guild.icon_url)
  await ctx.send(embed=embed)





@bot.command()
async def streaming(ctx, *, message): #  
    await ctx.message.delete()
    stream = discord.Streaming(
        name=message,
        url=stream_url, 
    )
    await bot.change_presence(activity=stream) 

@bot.command()
async def listening(ctx, *, message): #  
    await ctx.message.delete()
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.listening, 
            name=message, 
        ))

@bot.command()
async def playing(ctx, *, message): #  
    await ctx.message.delete()
    game = discord.Game(
        name=message
    )
    await bot.change_presence(activity=game)

@bot.command()
async def watching(ctx, *, message): #  
    await ctx.message.delete()
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching, 
            name=message
        ))




@bot.command()
async def ping(ctx):
	channel = ctx.message.channel
	t1 = time.perf_counter()
	await channel.trigger_typing()
	t2 = time.perf_counter()
	embed=discord.Embed(title='Ping', description='<:ping:719289854038376578> Ping: {}ms'.format(round((t2-t1)*1000)), color=800000)
	await channel.send(embed=embed)     



@bot.command()
async def bb(ctx): #  
    await ctx.message.delete()
    await ctx.send('ﾠﾠ'+'\n' * 800 + 'ﾠﾠ')


@bot.command(pass_context=True)
async def avatar(ctx, member: discord.Member):
  member = ctx.author if not member else member

  embed = discord.Embed(colour=member.color, timestamp=ctx.message.created_at)
  
  embed.set_author(name=f"Avatar for {member}")
  embed.set_thumbnail(url=member.avatar_url)
  await ctx.send(embed=embed)



@bot.command()
async def lookup(ctx, member_id):
  member = await bot.fetch_user(member_id)
  embed = discord.Embed(title = f"User Info - **{member.name}#{member.discriminator}**", timestamp=ctx.message.created_at, color=discord.Color(800000))
  embed.add_field(name = "Username", value = f"``{member.name}#{member.discriminator}``", inline = False)
  embed.add_field(name = "User ID", value = member.id, inline = False)
  embed.add_field(name = "Account Creation Date", value = member.created_at.__format__('%A, %d. %B %Y @ %H:%M:%S'), inline = False)
  embed.add_field(name = "Bot?", value = member.bot, inline = False)
  embed.set_image(url = member.avatar_url)

  await ctx.channel.send(embed=embed)



@bot.command()
async def support(ctx):
  await ctx.message.delete()
  channel = ctx.message.channel
  embed=discord.Embed(title='𝙼𝚊𝚜𝚔𝚢𝙼𝚇 𝚂𝚎𝚕𝚏𝚋𝚘𝚝 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜', description= """ 𝙲𝚊𝚝𝚎𝚐𝚘𝚛𝚒𝚎𝚜
(For More Information On A Category, Do >>{category})

🔥 𝐒𝐞𝐫𝐯𝐞𝐫 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬
-------------------------
🔥 𝐔𝐬𝐞𝐫 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬
-------------------------
🔥 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬
-------------------------
🔥 𝐌𝐢𝐬𝐜 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬
-------------------------

😈 CREDIT! 😈
⇩⇩⇩
Discord tag: **ཊ☬ཏ MΛƧKY ཊ☬ཏ#0666**
GitHub: https://github.com/MaskyMx
ID: 733917864725184614

""",   color=0x450000)
  embed.set_image (url= "https://cdn.discordapp.com/attachments/796564244485242880/808792149730263090/source.gif")
  await channel.send(embed=embed) 


@bot.command()
async def server(ctx):
  await ctx.message.delete()
  channel = ctx.message.channel
  embed=discord.Embed(title='𝙼𝚊𝚜𝚔𝚢𝙼𝚇 𝚂𝚎𝚕𝚏𝚋𝚘𝚝 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜', description= """ 𝚂𝚎𝚛𝚟𝚎𝚛 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜
🔪 serverinfo
↳ 𝐆𝐢𝐯𝐞𝐬 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 𝐎𝐧 𝐀 𝐒𝐩𝐞𝐜𝐢𝐟𝐢𝐞𝐝 𝐒𝐞𝐫𝐯𝐞𝐫
-------------------------
🔪 nick {message}
↳ 𝐂𝐡𝐚𝐧𝐠𝐞𝐬 𝐘𝐨𝐮𝐫 𝐍𝐢𝐜𝐤𝐧𝐚𝐦𝐞 𝐈𝐧 𝐀 𝐒𝐞𝐫𝐯𝐞𝐫
-------------------------
""",   color=0x010045)
  embed.set_image (url= "https://media.discordapp.net/attachments/796564244485242880/808792599782883420/source_1.gif")
  await channel.send(embed=embed) 

@bot.command()
async def user(ctx):
  await ctx.message.delete()
  channel = ctx.message.channel
  embed=discord.Embed(title='𝙼𝚊𝚜𝚔𝚢𝙼𝚇 𝚂𝚎𝚕𝚏𝚋𝚘𝚝 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜', description= """ 𝚄𝚜𝚎𝚛 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜
👻 avatar
↳ 𝐒𝐡𝐨𝐰𝐬 𝐓𝐡𝐞 𝐀𝐯𝐚𝐭𝐚𝐫 𝐎𝐟 𝐌𝐞𝐧𝐭𝐢𝐨𝐧𝐞𝐝 𝐔𝐬𝐞𝐫
-------------------------
👻 lookup 
↳ 𝐆𝐢𝐯𝐞𝐬 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 𝐎𝐧 𝐀 𝐒𝐩𝐞𝐜𝐢𝐟𝐢𝐞𝐝 𝐔𝐬𝐞𝐫
-------------------------
👻 ping
↳ 𝐏𝐫𝐨𝐯𝐢𝐝𝐞'𝐬 𝐀 𝐒𝐩𝐞𝐜𝐢𝐟𝐢𝐞𝐝 𝐔𝐬𝐞𝐫'𝐬 𝐏𝐢𝐧𝐠
-------------------------

""",   color=0xFFFFFF)
  embed.set_image(url = "https://media.discordapp.net/attachments/796564244485242880/808795051102437456/giphy_1.gif")
  await channel.send(embed=embed) 


@bot.command()
async def status(ctx):
  await ctx.message.delete()
  channel = ctx.message.channel
  embed=discord.Embed(title='𝙼𝚊𝚜𝚔𝚢𝙼𝚇 𝚂𝚎𝚕𝚏𝚋𝚘𝚝 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜', description= """ 𝚂𝚝𝚊𝚝𝚞𝚜 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜
💣 listening {message}
↳ 𝐂𝐡𝐚𝐧𝐠𝐞𝐬 𝐘𝐨𝐮𝐫 𝐒𝐭𝐚𝐭𝐮𝐬 𝐓𝐨 "𝐋𝐢𝐬𝐭𝐞𝐧𝐢𝐧𝐠 𝐓𝐨 ---"
-------------------------
💣 watching {message} 
↳ 𝐂𝐡𝐚𝐧𝐠𝐞𝐬 𝐘𝐨𝐮𝐫 𝐒𝐭𝐚𝐭𝐮𝐬 𝐓𝐨 "𝐖𝐚𝐭𝐜𝐡𝐢𝐧𝐠  ---"
-------------------------
💣 streaming {message}
↳ 𝐂𝐡𝐚𝐧𝐠𝐞𝐬 𝐘𝐨𝐮𝐫 𝐒𝐭𝐚𝐭𝐮𝐬 𝐓𝐨 "𝐒𝐭𝐫𝐞𝐚𝐦𝐢𝐧𝐠  ---"
-------------------------
💣 playing {message}
↳ 𝐂𝐡𝐚𝐧𝐠𝐞𝐬 𝐘𝐨𝐮𝐫 𝐒𝐭𝐚𝐭𝐮𝐬 𝐓𝐨 "𝐏𝐥𝐚𝐲𝐢𝐧𝐠 --- "
-------------------------

""",   color=0x000000)
  embed.set_image(url = "https://media.discordapp.net/attachments/796564244485242880/808793368612044930/295da1f7856d2f5f8c3c18af0d3f9b7d.gif")
  await channel.send(embed=embed) 


@bot.command()
async def misc(ctx):
  await ctx.message.delete()
  channel = ctx.message.channel
  embed=discord.Embed(title='𝙼𝚊𝚜𝚔𝚢𝙼𝚇 𝚂𝚎𝚕𝚏𝚋𝚘𝚝 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜', description= """ 𝙼𝚒𝚜𝚌𝚎𝚕𝚕𝚊𝚗𝚎𝚘𝚞𝚜 𝙲𝚘𝚖𝚖𝚊𝚗𝚍𝚜
🍇 masky 
↳ 𝐌𝐚𝐬𝐬 𝐃𝐞𝐥𝐞𝐭𝐞𝐬 𝐘𝐨𝐮𝐫 𝐌𝐞𝐬𝐬𝐚𝐠𝐞𝐬
-------------------------
🍇 bb 
↳ 𝐒𝐞𝐧𝐝𝐬 𝐀 𝐁𝐥𝐚𝐧𝐤 𝐁𝐨𝐦𝐛 (𝐀 𝐋𝐨𝐧𝐠 𝐁𝐥𝐚𝐧𝐤 𝐌𝐞𝐬𝐬𝐚𝐠𝐞)
-------------------------
🍇 shrug
↳ 𝐒𝐞𝐧𝐝𝐬 𝐀 𝐒𝐡𝐫𝐮𝐠
-------------------------
🍇 lenny
↳ 𝐒𝐞𝐧𝐝𝐬 𝐀 𝐋𝐞𝐧𝐧𝐲
-------------------------
🍇 tableflip 
↳ 𝐒𝐞𝐧𝐝𝐬 𝐀 𝐓𝐚𝐛𝐥𝐞 𝐅𝐥𝐢𝐩
-------------------------
🍇 unflip
↳ 𝐒𝐞𝐧𝐝𝐬 𝐀 𝐑𝐞𝐯𝐞𝐫𝐬𝐞 𝐓𝐚𝐛𝐥𝐞 𝐅𝐥𝐢𝐩
-------------------------
🍇 massreact {emoji}
↳ 𝐌𝐚𝐬𝐬 𝐑𝐞𝐚𝐜𝐭𝐬 𝐓𝐨 𝐌𝐞𝐬𝐬𝐚𝐠𝐞𝐬
-------------------------
🍇 abc
↳ 𝐄𝐝𝐢𝐭𝐬 𝐘𝐨𝐮𝐫 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 𝐓𝐨 𝐓𝐡𝐞 𝐀𝐥𝐩𝐡𝐚𝐛𝐞𝐭
-------------------------
🍇 cum
↳ 𝐄𝐝𝐢𝐭𝐬 𝐘𝐨𝐮𝐫 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 𝐓𝐨 𝐋𝐨𝐨𝐤 𝐋𝐢𝐤𝐞 𝐒𝐨𝐦𝐞𝐨𝐧𝐞 𝐈𝐬 𝐉𝐚𝐜𝐤𝐢𝐧' 𝐎𝐟𝐟
-------------------------
🍇 osama
↳ 𝐄𝐝𝐢𝐭𝐬 𝐘𝐨𝐮𝐫 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 𝐓𝐨 𝐋𝐨𝐨𝐤 𝐋𝐢𝐤𝐞 𝟗/𝟏𝟏
-------------------------

""",   color=0x300444)
  embed.set_image(url = "https://cdn.discordapp.com/attachments/796564244485242880/808795953531584575/original.gif")
  await channel.send(embed=embed)



@bot.command()
async def osama(ctx):
 await ctx.message.delete()
 invis = ""  # char(173)
 message = await ctx.send(f'''
{invis}:man_wearing_turban::airplane:    :office:           
''')
 await asyncio.sleep(0.5)
 await message.edit(content=f'''
{invis} :man_wearing_turban::airplane:   :office:           
''')
 await asyncio.sleep(0.5)
 await message.edit(content=f'''
{invis}  :man_wearing_turban::airplane:  :office:           
''')
 await asyncio.sleep(0.5)
 await message.edit(content=f'''
{invis}   :man_wearing_turban::airplane: :office:           
''')
 await asyncio.sleep(0.5)
 await message.edit(content=f'''
{invis}    :man_wearing_turban::airplane::office:           
''')
 await asyncio.sleep(0.5)
 await message.edit(content='''
        :boom::boom::boom:    
        ''')




@bot.command(aliases=["jerkoff", "ejaculate", "orgasm"])
async def cum(ctx):
    await ctx.message.delete()
    message = await ctx.send('''
            :ok_hand:            :smile:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant:''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                      :ok_hand:            :smiley:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant:  
     ''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                      :ok_hand:            :grimacing:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant:  
     ''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                      :ok_hand:            :persevere:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant:   
     ''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                      :ok_hand:            :confounded:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant: 
     ''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                       :ok_hand:            :tired_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant:    
             ''')
    await asyncio.sleep(0.5)
    await message.edit(contnet='''
                       :ok_hand:            :weary:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:= D:sweat_drops:
             :trumpet:      :eggplant:        
     ''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                       :ok_hand:            :dizzy_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D :sweat_drops:
             :trumpet:      :eggplant:                 :sweat_drops:
     ''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
                       :ok_hand:            :drooling_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D :sweat_drops:
             :trumpet:      :eggplant:                 :sweat_drops:
     ''')


@bot.command()
async def abc(ctx):
    await ctx.message.delete()
    ABC = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'ñ', 'o', 'p', 'q', 'r', 's', 't', 'u',
           'v', 'w', 'x', 'y', 'z']
    message = await ctx.send(ABC[0])
    await asyncio.sleep(2)
    for _next in ABC[1:]:
        await message.edit(content=_next)
        await asyncio.sleep(2)


@bot.command()
async def shrug(ctx):
    await ctx.message.delete()
    shrug = r'¯\_(ツ)_/¯'
    await ctx.send(shrug)


@bot.command()
async def lenny(ctx):
    await ctx.message.delete()
    lenny = '( ͡° ͜ʖ ͡°)'
    await ctx.send(lenny)


@bot.command(aliases=["fliptable"])
async def tableflip(ctx):
    await ctx.message.delete()
    tableflip = '(╯°□°）╯︵ ┻━┻'
    await ctx.send(tableflip)


@bot.command()
async def unflip(ctx):
    await ctx.message.delete()
    unflip = '┬─┬ ノ( ゜-゜ノ)'
    await ctx.send(unflip)

@bot.command()
async def nine_eleven(ctx):
    await ctx.message.delete()
    invis = ""  # char(173)
    message = await ctx.send(f'''
{invis}:man_wearing_turban::airplane:    :office:           
''')
    await asyncio.sleep(0.5)
    await message.edit(content=f'''
{invis} :man_wearing_turban::airplane:   :office:           
''')
    await asyncio.sleep(0.5)
    await message.edit(content=f'''
{invis}  :man_wearing_turban::airplane:  :office:           
''')
    await asyncio.sleep(0.5)
    await message.edit(content=f'''
{invis}   :man_wearing_turban::airplane: :office:           
''')
    await asyncio.sleep(0.5)
    await message.edit(content=f'''
{invis}    :man_wearing_turban::airplane::office:           
''')
    await asyncio.sleep(0.5)
    await message.edit(content='''
        :boom::boom::boom:    
        ''')


@bot.command()
async def massreact(ctx, emote):
  await ctx.message.delete()
  messages = await ctx.message.channel.history(limit=100).flatten()
  for message in messages:
        await message.add_reaction(emote)



@bot.event
async def on_connect():
    await asyncio.sleep(1)
    print(
        f"{Fore.GREEN}That's it! You're all ready to go! You are currently logged is as {Style.RESET_ALL}{bot.user.name}#{bot.user.discriminator}\n \n"
    )
print(Style.DIM + 'Use This Bot Wisely, I Am Not Responsible For Any Improper Use')
print(Fore.RED + 'Any Questions, DM ཊ☬ཏ MΛƧKY ཊ☬ཏ#0666')
print(Fore.RED + Style.DIM + 'For Command List, Use The Command Below ↓↓↓ ')
print(Fore.WHITE + Style.BRIGHT + '>>support')


bot.run('',bot=False)

##Input your token in the ' '##